# Durian-Rambutan > 2024-12-18 3:10pm
https://universe.roboflow.com/nyp-iti107/durian-rambutan

Provided by a Roboflow user
License: MIT

